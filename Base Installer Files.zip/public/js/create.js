$(document).ready(function () {
  if (!document.hidden && localStorage.explicit && localStorage.Snapster && localStorage.current_token && localStorage.party && localStorage.lastFM && localStorage.userID && localStorage.explicit && localStorage.password ) {
    var party;
    var userPrompt;
    var obj2 = {};
    window.newToken = function () {
        $.ajax({
	    type: "GET",
            url: '/refresh_token',
            data: {
                'refresh_token': localStorage["refresh_token"]
            }
        }).done(function (data) {
            access_token = data.access_token;
            localStorage["current_token"] = data.access_token;
            create();
        });
    }
    newToken();
    window.create = function () {
        try {
            localStorage["valid"] = "true";
            $.ajax({
                async: true,
                type: "GET",
                url: "https://api.spotify.com/v1/me",
                headers: { 'Authorization': 'Bearer ' + localStorage["current_token"] },
                dataType: "json",
                data: "formdata",
                success: function (userData) {
                    localStorage['userID'] = userData.id;
                    userID = localStorage['userID'];
                    localStorage["valid"] = "true";
                },
                error: function () {
                   // localStorage["valid"] = "false";
                    if (localStorage["current_token"].length > 3) {
                     //   newToken();
                    }
                }
            });
         if (localStorage["party"].length > 3 && localStorage["password"].length > 3 && localStorage["lastFM"].length > 3 && (window.location.pathname || localStorage.party)) {
                  try {
                    obj2["party"] = localStorage["party"];
                    obj2["lastFM"] = localStorage["party"];
                    obj2["playlist"] = localStorage['Snapster'];
                    obj2["access_token"] = localStorage["current_token"];
                    obj2["username"] = localStorage['userID'];
                    obj2["explicit"] = localStorage['explicit'];
                    obj2["password"] = localStorage['password'];
		    obj2["refresh_token"] = localStorage['refresh_token'];
                    $.ajax({
                        async: true,
                        dataType: "json",
                        type: "POST",
                        data: obj2,
                        url: '/',
                        success: function (accessDataset) {
                            console.log("Success");
                            if (!accessDataset["invalid"]) {
                                $("#dialogEnjoy").dialog();
                                localStorage["invalid"] = "false";
                                $("#dialog").hide();
                                localStorage.setItem("host", true);
                                // console.log(accessDataset);
                                var token = accessDataset;
                                nextSongs();
                                currentSong();
                                snapsterPlaylist();
				    if(location.href.indexOf("/index.html")<1){location.href = "http://localhost:8080/index.html";}
			    }
				else {
					window.location.href = "http://localhost:8080/index.html";
				}
			},
                error: function () {
		/*if (localStorage.guest != "true" && localStorage.guest != true) {
                   location.href="/error";
		}*/
                }
                    });
                }
                catch (exception) {
                    console.log(exception);
                }
            }
        }
        catch (exception) {
            // console.log(exception);
        }
    }
   // create();
    }
	});
